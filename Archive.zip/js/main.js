var typed = new Typed('#typed', {
    stringsElement: '#typed-strings',
    typeSpeed: 60,
    backSpeed: 20,
    loop: true,
    loopCount: Infinity
});
